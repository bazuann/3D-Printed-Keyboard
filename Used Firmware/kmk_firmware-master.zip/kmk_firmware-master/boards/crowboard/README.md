# Crowboard
![Crowboard](https://i.imgur.com/Rg7IYPw.jpg)
 Single Board 34/36 Key Keyboard Based on Raspberry pi Pico

[Link to the GitHub repository](https://github.com/doesntfazer/CrowBoard)
